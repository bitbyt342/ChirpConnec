import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { upload, fileToDataUrl } from "./fileUpload";
import { insertPostSchema, insertCommentSchema, insertAdCampaignSchema, insertReportSchema } from "@shared/schema";
import Stripe from "stripe";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-09-30.clover",
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // User routes
  app.get('/api/users/search', async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Query parameter required" });
      }
      const users = await storage.searchUsers(query);
      res.json(users);
    } catch (error) {
      console.error("Error searching users:", error);
      res.status(500).json({ message: "Failed to search users" });
    }
  });

  app.get('/api/users/:id', async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.patch('/api/users/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      if (userId !== req.params.id) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const { username, bio } = req.body;
      const user = await storage.updateUserProfile(userId, { username, bio });
      res.json(user);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.get('/api/users/:id/followers', async (req, res) => {
    try {
      const followers = await storage.getFollowers(req.params.id);
      res.json(followers);
    } catch (error) {
      console.error("Error fetching followers:", error);
      res.status(500).json({ message: "Failed to fetch followers" });
    }
  });

  app.get('/api/users/:id/following', async (req, res) => {
    try {
      const following = await storage.getFollowing(req.params.id);
      res.json(following);
    } catch (error) {
      console.error("Error fetching following:", error);
      res.status(500).json({ message: "Failed to fetch following" });
    }
  });

  // Post routes
  app.post('/api/posts', isAuthenticated, upload.single('image'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { content } = req.body;
      
      const postData = insertPostSchema.parse({
        userId,
        content,
        imageUrl: req.file ? fileToDataUrl(req.file) : undefined,
      });

      const post = await storage.createPost(postData);
      res.json(post);
    } catch (error: any) {
      console.error("Error creating post:", error);
      res.status(400).json({ message: error.message || "Failed to create post" });
    }
  });

  app.get('/api/posts', async (req: any, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 20;
      const offset = parseInt(req.query.offset as string) || 0;
      const userId = req.user?.claims?.sub;
      
      const posts = await storage.getPosts(limit, offset, userId);
      res.json(posts);
    } catch (error) {
      console.error("Error fetching posts:", error);
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });

  app.get('/api/posts/:id', async (req, res) => {
    try {
      const post = await storage.getPostById(req.params.id);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      res.json(post);
    } catch (error) {
      console.error("Error fetching post:", error);
      res.status(500).json({ message: "Failed to fetch post" });
    }
  });

  app.get('/api/users/:id/posts', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 20;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const posts = await storage.getPostsByUserId(req.params.id, limit, offset);
      res.json(posts);
    } catch (error) {
      console.error("Error fetching user posts:", error);
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });

  app.delete('/api/posts/:id', isAuthenticated, async (req: any, res) => {
    try {
      const post = await storage.getPostById(req.params.id);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (post.userId !== userId && !user?.isAdmin) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      await storage.deletePost(req.params.id);
      res.json({ message: "Post deleted" });
    } catch (error) {
      console.error("Error deleting post:", error);
      res.status(500).json({ message: "Failed to delete post" });
    }
  });

  // Like routes
  app.post('/api/posts/:id/like', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const postId = req.params.id;
      
      const isLiked = await storage.isPostLiked(userId, postId);
      if (isLiked) {
        await storage.unlikePost(userId, postId);
        res.json({ liked: false });
      } else {
        await storage.likePost(userId, postId);
        res.json({ liked: true });
      }
    } catch (error) {
      console.error("Error toggling like:", error);
      res.status(500).json({ message: "Failed to toggle like" });
    }
  });

  // Comment routes
  app.post('/api/posts/:id/comments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const postId = req.params.id;
      const { content } = req.body;
      
      const commentData = insertCommentSchema.parse({
        userId,
        postId,
        content,
      });

      const comment = await storage.createComment(commentData);
      res.json(comment);
    } catch (error: any) {
      console.error("Error creating comment:", error);
      res.status(400).json({ message: error.message || "Failed to create comment" });
    }
  });

  app.get('/api/posts/:id/comments', async (req, res) => {
    try {
      const comments = await storage.getCommentsByPostId(req.params.id);
      res.json(comments);
    } catch (error) {
      console.error("Error fetching comments:", error);
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  // Repost routes
  app.post('/api/posts/:id/repost', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const postId = req.params.id;
      
      const isReposted = await storage.isPostReposted(userId, postId);
      if (isReposted) {
        await storage.unrepostPost(userId, postId);
        res.json({ reposted: false });
      } else {
        await storage.repostPost(userId, postId);
        res.json({ reposted: true });
      }
    } catch (error) {
      console.error("Error toggling repost:", error);
      res.status(500).json({ message: "Failed to toggle repost" });
    }
  });

  // Follow routes
  app.post('/api/users/:id/follow', isAuthenticated, async (req: any, res) => {
    try {
      const followerId = req.user.claims.sub;
      const followingId = req.params.id;
      
      if (followerId === followingId) {
        return res.status(400).json({ message: "Cannot follow yourself" });
      }
      
      const isFollowing = await storage.isFollowing(followerId, followingId);
      if (isFollowing) {
        await storage.unfollowUser(followerId, followingId);
        res.json({ following: false });
      } else {
        await storage.followUser(followerId, followingId);
        res.json({ following: true });
      }
    } catch (error) {
      console.error("Error toggling follow:", error);
      res.status(500).json({ message: "Failed to toggle follow" });
    }
  });

  app.get('/api/users/:id/is-following', isAuthenticated, async (req: any, res) => {
    try {
      const followerId = req.user.claims.sub;
      const followingId = req.params.id;
      
      const isFollowing = await storage.isFollowing(followerId, followingId);
      res.json({ following: isFollowing });
    } catch (error) {
      console.error("Error checking follow status:", error);
      res.status(500).json({ message: "Failed to check follow status" });
    }
  });

  // Hashtag routes
  app.get('/api/hashtags/trending', async (req, res) => {
    try {
      const hashtags = await storage.getTrendingHashtags();
      res.json(hashtags);
    } catch (error) {
      console.error("Error fetching trending hashtags:", error);
      res.status(500).json({ message: "Failed to fetch trending hashtags" });
    }
  });

  // Stripe subscription routes
  app.post('/api/create-subscription', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      let user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.stripeSubscriptionId) {
        const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
        return res.json({
          subscriptionId: subscription.id,
          clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret,
        });
      }

      if (!user.email) {
        return res.status(400).json({ message: "No user email on file" });
      }

      const customer = await stripe.customers.create({
        email: user.email,
        name: user.username || `${user.firstName} ${user.lastName}`,
      });

      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [{
          price: process.env.STRIPE_PRICE_ID,
        }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
      });

      await storage.updateUserStripeInfo(userId, customer.id, subscription.id);

      res.json({
        subscriptionId: subscription.id,
        clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret,
      });
    } catch (error: any) {
      console.error("Error creating subscription:", error);
      res.status(500).json({ message: error.message || "Failed to create subscription" });
    }
  });

  // Ad Campaign routes
  app.post('/api/ad-campaigns', isAuthenticated, upload.single('creative'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const campaignData = insertAdCampaignSchema.parse({
        userId,
        name: req.body.name,
        objective: req.body.objective,
        creativeUrl: req.file ? fileToDataUrl(req.file) : undefined,
        adCopy: req.body.adCopy,
        targetAgeRange: req.body.targetAgeRange,
        targetGender: req.body.targetGender,
        targetInterests: req.body.targetInterests,
        dailyBudget: parseInt(req.body.dailyBudget),
        durationDays: parseInt(req.body.durationDays),
      });

      const campaign = await storage.createAdCampaign(campaignData);
      res.json(campaign);
    } catch (error: any) {
      console.error("Error creating ad campaign:", error);
      res.status(400).json({ message: error.message || "Failed to create ad campaign" });
    }
  });

  app.get('/api/ad-campaigns', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const campaigns = await storage.getAdCampaigns(userId);
      res.json(campaigns);
    } catch (error) {
      console.error("Error fetching ad campaigns:", error);
      res.status(500).json({ message: "Failed to fetch ad campaigns" });
    }
  });

  // Report routes
  app.post('/api/reports', isAuthenticated, async (req: any, res) => {
    try {
      const reporterId = req.user.claims.sub;
      const reportData = insertReportSchema.parse({
        reporterId,
        postId: req.body.postId || null,
        userId: req.body.userId || null,
        reason: req.body.reason,
        description: req.body.description,
      });

      const report = await storage.createReport(reportData);
      res.json(report);
    } catch (error: any) {
      console.error("Error creating report:", error);
      res.status(400).json({ message: error.message || "Failed to create report" });
    }
  });

  // Admin routes
  const requireAdmin = async (req: any, res: any, next: any) => {
    const userId = req.user.claims.sub;
    const user = await storage.getUser(userId);
    
    if (!user?.isAdmin) {
      return res.status(403).json({ message: "Admin access required" });
    }
    next();
  };

  app.get('/api/admin/users', isAuthenticated, requireAdmin, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const users = await storage.getUsers(limit, offset);
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.post('/api/admin/users/:id/suspend', isAuthenticated, requireAdmin, async (req, res) => {
    try {
      await storage.suspendUser(req.params.id);
      res.json({ message: "User suspended" });
    } catch (error) {
      console.error("Error suspending user:", error);
      res.status(500).json({ message: "Failed to suspend user" });
    }
  });

  app.post('/api/admin/users/:id/unsuspend', isAuthenticated, requireAdmin, async (req, res) => {
    try {
      await storage.unsuspendUser(req.params.id);
      res.json({ message: "User unsuspended" });
    } catch (error) {
      console.error("Error unsuspending user:", error);
      res.status(500).json({ message: "Failed to unsuspend user" });
    }
  });

  app.post('/api/admin/users/:id/verify', isAuthenticated, requireAdmin, async (req, res) => {
    try {
      await storage.verifyUser(req.params.id);
      res.json({ message: "User verified" });
    } catch (error) {
      console.error("Error verifying user:", error);
      res.status(500).json({ message: "Failed to verify user" });
    }
  });

  app.get('/api/admin/reports', isAuthenticated, requireAdmin, async (req, res) => {
    try {
      const status = req.query.status as string | undefined;
      const reports = await storage.getReports(status);
      res.json(reports);
    } catch (error) {
      console.error("Error fetching reports:", error);
      res.status(500).json({ message: "Failed to fetch reports" });
    }
  });

  app.patch('/api/admin/reports/:id', isAuthenticated, requireAdmin, async (req, res) => {
    try {
      const { status } = req.body;
      await storage.updateReportStatus(req.params.id, status);
      res.json({ message: "Report updated" });
    } catch (error) {
      console.error("Error updating report:", error);
      res.status(500).json({ message: "Failed to update report" });
    }
  });

  app.get('/api/admin/ad-campaigns', isAuthenticated, requireAdmin, async (req, res) => {
    try {
      const status = req.query.status as string | undefined;
      const campaigns = await storage.getAllAdCampaigns(status);
      res.json(campaigns);
    } catch (error) {
      console.error("Error fetching ad campaigns:", error);
      res.status(500).json({ message: "Failed to fetch ad campaigns" });
    }
  });

  app.patch('/api/admin/ad-campaigns/:id', isAuthenticated, requireAdmin, async (req, res) => {
    try {
      const { status } = req.body;
      await storage.updateAdCampaignStatus(req.params.id, status);
      res.json({ message: "Ad campaign updated" });
    } catch (error) {
      console.error("Error updating ad campaign:", error);
      res.status(500).json({ message: "Failed to update ad campaign" });
    }
  });

  app.get('/api/admin/stats', isAuthenticated, requireAdmin, async (req, res) => {
    try {
      const [userStats, postStats, revenueStats] = await Promise.all([
        storage.getUserStats(),
        storage.getPostStats(),
        storage.getRevenueStats(),
      ]);
      
      res.json({
        ...userStats,
        ...postStats,
        ...revenueStats,
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
