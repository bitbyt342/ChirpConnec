import {
  users,
  posts,
  likes,
  comments,
  reposts,
  follows,
  hashtags,
  postHashtags,
  adCampaigns,
  reports,
  type User,
  type UpsertUser,
  type Post,
  type InsertPost,
  type Like,
  type Comment,
  type InsertComment,
  type Repost,
  type Follow,
  type Hashtag,
  type AdCampaign,
  type InsertAdCampaign,
  type Report,
  type InsertReport,
  type PostWithUser,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, or, inArray, ne } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserProfile(id: string, data: Partial<User>): Promise<User>;
  updateUserStripeInfo(id: string, stripeCustomerId: string, stripeSubscriptionId: string): Promise<User>;
  searchUsers(query: string, limit?: number): Promise<User[]>;
  
  // Post operations
  createPost(post: InsertPost): Promise<Post>;
  getPosts(limit: number, offset: number, userId?: string): Promise<PostWithUser[]>;
  getPostById(id: string): Promise<PostWithUser | undefined>;
  getPostsByUserId(userId: string, limit: number, offset: number): Promise<PostWithUser[]>;
  deletePost(id: string): Promise<void>;
  
  // Like operations
  likePost(userId: string, postId: string): Promise<void>;
  unlikePost(userId: string, postId: string): Promise<void>;
  isPostLiked(userId: string, postId: string): Promise<boolean>;
  
  // Comment operations
  createComment(comment: InsertComment): Promise<Comment>;
  getCommentsByPostId(postId: string): Promise<Array<Comment & { user: User }>>;
  
  // Repost operations
  repostPost(userId: string, postId: string): Promise<void>;
  unrepostPost(userId: string, postId: string): Promise<void>;
  isPostReposted(userId: string, postId: string): Promise<boolean>;
  
  // Follow operations
  followUser(followerId: string, followingId: string): Promise<void>;
  unfollowUser(followerId: string, followingId: string): Promise<void>;
  isFollowing(followerId: string, followingId: string): Promise<boolean>;
  getFollowers(userId: string): Promise<User[]>;
  getFollowing(userId: string): Promise<User[]>;
  
  // Hashtag operations
  getTrendingHashtags(limit?: number): Promise<Hashtag[]>;
  
  // Ad Campaign operations
  createAdCampaign(campaign: InsertAdCampaign): Promise<AdCampaign>;
  getAdCampaigns(userId: string): Promise<AdCampaign[]>;
  getAllAdCampaigns(status?: string): Promise<AdCampaign[]>;
  updateAdCampaignStatus(id: string, status: string): Promise<void>;
  
  // Report operations
  createReport(report: InsertReport): Promise<Report>;
  getReports(status?: string): Promise<Array<Report & { reporter: User, post?: Post, user?: User }>>;
  updateReportStatus(id: string, status: string): Promise<void>;
  
  // Admin operations
  getUsers(limit: number, offset: number): Promise<User[]>;
  suspendUser(id: string): Promise<void>;
  unsuspendUser(id: string): Promise<void>;
  verifyUser(id: string): Promise<void>;
  unverifyUser(id: string): Promise<void>;
  
  // Analytics
  getUserStats(): Promise<{ totalUsers: number; verifiedUsers: number }>;
  getPostStats(): Promise<{ totalPosts: number; todayPosts: number }>;
  getRevenueStats(): Promise<{ monthlyRevenue: number }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserProfile(id: string, data: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserStripeInfo(id: string, stripeCustomerId: string, stripeSubscriptionId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        stripeCustomerId,
        stripeSubscriptionId,
        isVerified: true,
        updatedAt: new Date() 
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async searchUsers(query: string, limit: number = 10): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .where(
        or(
          sql`${users.username} ILIKE ${`%${query}%`}`,
          sql`${users.firstName} ILIKE ${`%${query}%`}`,
          sql`${users.lastName} ILIKE ${`%${query}%`}`
        )
      )
      .limit(limit);
  }

  async createPost(postData: InsertPost): Promise<Post> {
    const [post] = await db.insert(posts).values(postData).returning();
    
    // Extract hashtags and create them
    const hashtagRegex = /#(\w+)/g;
    const hashtagMatches = postData.content.match(hashtagRegex);
    
    if (hashtagMatches) {
      for (const match of hashtagMatches) {
        const tag = match.substring(1).toLowerCase();
        
        // Upsert hashtag
        const [hashtag] = await db
          .insert(hashtags)
          .values({ tag })
          .onConflictDoUpdate({
            target: hashtags.tag,
            set: { postsCount: sql`${hashtags.postsCount} + 1` },
          })
          .returning();
        
        // Link post to hashtag
        await db.insert(postHashtags).values({
          postId: post.id,
          hashtagId: hashtag.id,
        });
      }
    }
    
    return post;
  }

  async getPosts(limit: number, offset: number, currentUserId?: string): Promise<PostWithUser[]> {
    const postsData = await db
      .select({
        post: posts,
        user: users,
      })
      .from(posts)
      .leftJoin(users, eq(posts.userId, users.id))
      .orderBy(desc(posts.createdAt))
      .limit(limit)
      .offset(offset);

    if (!currentUserId) {
      return postsData.map(({ post, user }) => ({ ...post, user: user! }));
    }

    // Check if posts are liked/reposted by current user
    const postIds = postsData.map(({ post }) => post.id);
    const userLikes = await db
      .select()
      .from(likes)
      .where(and(eq(likes.userId, currentUserId), inArray(likes.postId, postIds)));
    
    const userReposts = await db
      .select()
      .from(reposts)
      .where(and(eq(reposts.userId, currentUserId), inArray(reposts.postId, postIds)));

    const likedPostIds = new Set(userLikes.map(l => l.postId));
    const repostedPostIds = new Set(userReposts.map(r => r.postId));

    return postsData.map(({ post, user }) => ({
      ...post,
      user: user!,
      isLiked: likedPostIds.has(post.id),
      isReposted: repostedPostIds.has(post.id),
    }));
  }

  async getPostById(id: string): Promise<PostWithUser | undefined> {
    const [result] = await db
      .select({
        post: posts,
        user: users,
      })
      .from(posts)
      .leftJoin(users, eq(posts.userId, users.id))
      .where(eq(posts.id, id));

    if (!result) return undefined;
    return { ...result.post, user: result.user! };
  }

  async getPostsByUserId(userId: string, limit: number, offset: number): Promise<PostWithUser[]> {
    const postsData = await db
      .select({
        post: posts,
        user: users,
      })
      .from(posts)
      .leftJoin(users, eq(posts.userId, users.id))
      .where(eq(posts.userId, userId))
      .orderBy(desc(posts.createdAt))
      .limit(limit)
      .offset(offset);

    return postsData.map(({ post, user }) => ({ ...post, user: user! }));
  }

  async deletePost(id: string): Promise<void> {
    await db.delete(posts).where(eq(posts.id, id));
  }

  async likePost(userId: string, postId: string): Promise<void> {
    await db.insert(likes).values({ userId, postId });
    await db
      .update(posts)
      .set({ likesCount: sql`${posts.likesCount} + 1` })
      .where(eq(posts.id, postId));
  }

  async unlikePost(userId: string, postId: string): Promise<void> {
    await db.delete(likes).where(and(eq(likes.userId, userId), eq(likes.postId, postId)));
    await db
      .update(posts)
      .set({ likesCount: sql`${posts.likesCount} - 1` })
      .where(eq(posts.id, postId));
  }

  async isPostLiked(userId: string, postId: string): Promise<boolean> {
    const [like] = await db
      .select()
      .from(likes)
      .where(and(eq(likes.userId, userId), eq(likes.postId, postId)));
    return !!like;
  }

  async createComment(commentData: InsertComment): Promise<Comment> {
    const [comment] = await db.insert(comments).values(commentData).returning();
    await db
      .update(posts)
      .set({ commentsCount: sql`${posts.commentsCount} + 1` })
      .where(eq(posts.id, commentData.postId));
    return comment;
  }

  async getCommentsByPostId(postId: string): Promise<Array<Comment & { user: User }>> {
    const commentsData = await db
      .select({
        comment: comments,
        user: users,
      })
      .from(comments)
      .leftJoin(users, eq(comments.userId, users.id))
      .where(eq(comments.postId, postId))
      .orderBy(desc(comments.createdAt));

    return commentsData.map(({ comment, user }) => ({ ...comment, user: user! }));
  }

  async repostPost(userId: string, postId: string): Promise<void> {
    await db.insert(reposts).values({ userId, postId });
    await db
      .update(posts)
      .set({ repostsCount: sql`${posts.repostsCount} + 1` })
      .where(eq(posts.id, postId));
  }

  async unrepostPost(userId: string, postId: string): Promise<void> {
    await db.delete(reposts).where(and(eq(reposts.userId, userId), eq(reposts.postId, postId)));
    await db
      .update(posts)
      .set({ repostsCount: sql`${posts.repostsCount} - 1` })
      .where(eq(posts.id, postId));
  }

  async isPostReposted(userId: string, postId: string): Promise<boolean> {
    const [repost] = await db
      .select()
      .from(reposts)
      .where(and(eq(reposts.userId, userId), eq(reposts.postId, postId)));
    return !!repost;
  }

  async followUser(followerId: string, followingId: string): Promise<void> {
    await db.insert(follows).values({ followerId, followingId });
    await db
      .update(users)
      .set({ followingCount: sql`${users.followingCount} + 1` })
      .where(eq(users.id, followerId));
    await db
      .update(users)
      .set({ followersCount: sql`${users.followersCount} + 1` })
      .where(eq(users.id, followingId));
  }

  async unfollowUser(followerId: string, followingId: string): Promise<void> {
    await db.delete(follows).where(and(eq(follows.followerId, followerId), eq(follows.followingId, followingId)));
    await db
      .update(users)
      .set({ followingCount: sql`${users.followingCount} - 1` })
      .where(eq(users.id, followerId));
    await db
      .update(users)
      .set({ followersCount: sql`${users.followersCount} - 1` })
      .where(eq(users.id, followingId));
  }

  async isFollowing(followerId: string, followingId: string): Promise<boolean> {
    const [follow] = await db
      .select()
      .from(follows)
      .where(and(eq(follows.followerId, followerId), eq(follows.followingId, followingId)));
    return !!follow;
  }

  async getFollowers(userId: string): Promise<User[]> {
    const followers = await db
      .select({ user: users })
      .from(follows)
      .leftJoin(users, eq(follows.followerId, users.id))
      .where(eq(follows.followingId, userId));
    return followers.map(f => f.user!);
  }

  async getFollowing(userId: string): Promise<User[]> {
    const following = await db
      .select({ user: users })
      .from(follows)
      .leftJoin(users, eq(follows.followingId, users.id))
      .where(eq(follows.followerId, userId));
    return following.map(f => f.user!);
  }

  async getTrendingHashtags(limit: number = 10): Promise<Hashtag[]> {
    return await db
      .select()
      .from(hashtags)
      .orderBy(desc(hashtags.postsCount))
      .limit(limit);
  }

  async createAdCampaign(campaignData: InsertAdCampaign): Promise<AdCampaign> {
    const [campaign] = await db.insert(adCampaigns).values(campaignData).returning();
    return campaign;
  }

  async getAdCampaigns(userId: string): Promise<AdCampaign[]> {
    return await db
      .select()
      .from(adCampaigns)
      .where(eq(adCampaigns.userId, userId))
      .orderBy(desc(adCampaigns.createdAt));
  }

  async getAllAdCampaigns(status?: string): Promise<AdCampaign[]> {
    if (status) {
      return await db
        .select()
        .from(adCampaigns)
        .where(eq(adCampaigns.status, status))
        .orderBy(desc(adCampaigns.createdAt));
    }
    return await db
      .select()
      .from(adCampaigns)
      .orderBy(desc(adCampaigns.createdAt));
  }

  async updateAdCampaignStatus(id: string, status: string): Promise<void> {
    await db
      .update(adCampaigns)
      .set({ status })
      .where(eq(adCampaigns.id, id));
  }

  async createReport(reportData: InsertReport): Promise<Report> {
    const [report] = await db.insert(reports).values(reportData).returning();
    return report;
  }

  async getReports(status?: string): Promise<Array<Report & { reporter: User, post?: Post, user?: User }>> {
    const query = db
      .select({
        report: reports,
        reporter: users,
        post: posts,
        reportedUser: users,
      })
      .from(reports)
      .leftJoin(users, eq(reports.reporterId, users.id))
      .leftJoin(posts, eq(reports.postId, posts.id))
      .orderBy(desc(reports.createdAt));

    const reportsData = status
      ? await query.where(eq(reports.status, status))
      : await query;

    return reportsData.map(({ report, reporter, post, reportedUser }) => ({
      ...report,
      reporter: reporter!,
      post: post || undefined,
      user: reportedUser || undefined,
    }));
  }

  async updateReportStatus(id: string, status: string): Promise<void> {
    await db
      .update(reports)
      .set({ status })
      .where(eq(reports.id, id));
  }

  async getUsers(limit: number, offset: number): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .orderBy(desc(users.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async suspendUser(id: string): Promise<void> {
    await db
      .update(users)
      .set({ isSuspended: true })
      .where(eq(users.id, id));
  }

  async unsuspendUser(id: string): Promise<void> {
    await db
      .update(users)
      .set({ isSuspended: false })
      .where(eq(users.id, id));
  }

  async verifyUser(id: string): Promise<void> {
    await db
      .update(users)
      .set({ isVerified: true })
      .where(eq(users.id, id));
  }

  async unverifyUser(id: string): Promise<void> {
    await db
      .update(users)
      .set({ isVerified: false })
      .where(eq(users.id, id));
  }

  async getUserStats(): Promise<{ totalUsers: number; verifiedUsers: number }> {
    const [total] = await db.select({ count: sql<number>`count(*)::int` }).from(users);
    const [verified] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(users)
      .where(eq(users.isVerified, true));
    
    return {
      totalUsers: total.count,
      verifiedUsers: verified.count,
    };
  }

  async getPostStats(): Promise<{ totalPosts: number; todayPosts: number }> {
    const [total] = await db.select({ count: sql<number>`count(*)::int` }).from(posts);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const [todayCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(posts)
      .where(sql`${posts.createdAt} >= ${today}`);
    
    return {
      totalPosts: total.count,
      todayPosts: todayCount.count,
    };
  }

  async getRevenueStats(): Promise<{ monthlyRevenue: number }> {
    const [verified] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(users)
      .where(eq(users.isVerified, true));
    
    // Assume $8/month per verified user
    return {
      monthlyRevenue: verified.count * 8,
    };
  }
}

export const storage = new DatabaseStorage();
