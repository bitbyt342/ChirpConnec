import { useEffect, useState } from "react";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, BadgeCheck } from "lucide-react";

if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

function SubscribeForm() {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsSubmitting(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.origin,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Payment Successful",
        description: "You are now verified!",
      });
    }

    setIsSubmitting(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <Button 
        type="submit" 
        className="w-full" 
        disabled={!stripe || isSubmitting}
        data-testid="button-submit-payment"
      >
        {isSubmitting ? "Processing..." : "Subscribe"}
      </Button>
    </form>
  );
}

export default function Subscribe() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [clientSecret, setClientSecret] = useState("");
  const [selectedPlan, setSelectedPlan] = useState<"monthly" | "annual">("annual");

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }

    if (isAuthenticated) {
      apiRequest("POST", "/api/create-subscription")
        .then((res) => res.json())
        .then((data) => {
          setClientSecret(data.clientSecret);
        })
        .catch((error: Error) => {
          if (isUnauthorizedError(error)) {
            toast({
              title: "Unauthorized",
              description: "You are logged out. Logging in again...",
              variant: "destructive",
            });
            setTimeout(() => {
              window.location.href = "/api/login";
            }, 500);
            return;
          }
          toast({
            title: "Error",
            description: "Failed to initialize subscription",
            variant: "destructive",
          });
        });
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" aria-label="Loading" />
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" aria-label="Loading" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Hero */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-full mb-6">
            <BadgeCheck className="text-primary-foreground text-2xl" />
          </div>
          <h1 className="text-4xl font-bold mb-4" data-testid="text-page-title">Join the verified community</h1>
          <p className="text-xl text-muted-foreground">Get the Blue Tick and unlock exclusive features</p>
        </div>

        {/* Pricing Plans */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          <Card 
            className={`cursor-pointer transition-all ${
              selectedPlan === "monthly" ? "border-primary border-2" : "border-border"
            }`}
            onClick={() => setSelectedPlan("monthly")}
            data-testid="card-plan-monthly"
          >
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Monthly</CardTitle>
                  <CardDescription>Billed monthly</CardDescription>
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold">$8</p>
                  <p className="text-sm text-muted-foreground">/month</p>
                </div>
              </div>
            </CardHeader>
          </Card>

          <Card 
            className={`cursor-pointer transition-all relative ${
              selectedPlan === "annual" ? "border-primary border-2" : "border-border"
            }`}
            onClick={() => setSelectedPlan("annual")}
            data-testid="card-plan-annual"
          >
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-full">
              SAVE 20%
            </div>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Annual</CardTitle>
                  <CardDescription>Billed annually</CardDescription>
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold">$84</p>
                  <p className="text-sm text-muted-foreground">/year</p>
                </div>
              </div>
            </CardHeader>
          </Card>
        </div>

        {/* Payment Form */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle>Payment Details</CardTitle>
            <CardDescription>Enter your payment information to complete subscription</CardDescription>
          </CardHeader>
          <CardContent>
            <Elements stripe={stripePromise} options={{ clientSecret }}>
              <SubscribeForm />
            </Elements>
          </CardContent>
        </Card>

        {/* Features */}
        <Card>
          <CardHeader>
            <CardTitle>What's included:</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3">
              <Check className="text-primary mt-1 flex-shrink-0" />
              <div>
                <p className="font-semibold">Blue verification badge</p>
                <p className="text-sm text-muted-foreground">Stand out with the iconic Blue Tick</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="text-primary mt-1 flex-shrink-0" />
              <div>
                <p className="font-semibold">Priority support</p>
                <p className="text-sm text-muted-foreground">Get help when you need it most</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="text-primary mt-1 flex-shrink-0" />
              <div>
                <p className="font-semibold">Increased visibility</p>
                <p className="text-sm text-muted-foreground">Your posts get boosted in feeds</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="text-primary mt-1 flex-shrink-0" />
              <div>
                <p className="font-semibold">Edit posts</p>
                <p className="text-sm text-muted-foreground">Fix typos after posting</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="text-primary mt-1 flex-shrink-0" />
              <div>
                <p className="font-semibold">Longer posts</p>
                <p className="text-sm text-muted-foreground">Write up to 4,000 characters</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <p className="text-xs text-muted-foreground text-center mt-8">
          By subscribing, you agree to our Terms and Conditions. Subscription auto-renews until canceled.
        </p>
      </div>
    </div>
  );
}
