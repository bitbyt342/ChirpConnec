import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, CreditCard } from "lucide-react";
import type { AdCampaign } from "@shared/schema";

export default function AdCampaignManager() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const [creative, setCreative] = useState<File | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    objective: "Brand Awareness",
    adCopy: "",
    targetAgeRange: "18-24",
    targetGender: "All",
    targetInterests: "",
    dailyBudget: "",
    durationDays: "",
  });

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: campaigns, isLoading } = useQuery<AdCampaign[]>({
    queryKey: ["/api/ad-campaigns"],
  });

  const createCampaignMutation = useMutation({
    mutationFn: async () => {
      const data = new FormData();
      data.append("name", formData.name);
      data.append("objective", formData.objective);
      data.append("adCopy", formData.adCopy);
      data.append("targetAgeRange", formData.targetAgeRange);
      data.append("targetGender", formData.targetGender);
      data.append("targetInterests", formData.targetInterests);
      data.append("dailyBudget", formData.dailyBudget);
      data.append("durationDays", formData.durationDays);
      if (creative) {
        data.append("creative", creative);
      }

      const res = await fetch("/api/ad-campaigns", {
        method: "POST",
        body: data,
        credentials: "include",
      });

      if (!res.ok) {
        const error = await res.text();
        throw new Error(`${res.status}: ${error}`);
      }

      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ad-campaigns"] });
      toast({
        title: "Success",
        description: "Campaign created successfully",
      });
      // Reset form
      setFormData({
        name: "",
        objective: "Brand Awareness",
        adCopy: "",
        targetAgeRange: "18-24",
        targetGender: "All",
        targetInterests: "",
        dailyBudget: "",
        durationDays: "",
      });
      setCreative(null);
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create campaign",
        variant: "destructive",
      });
    },
  });

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const activeCampaigns = campaigns?.filter(c => c.status === "active") || [];
  const estimatedReach = formData.dailyBudget ? parseInt(formData.dailyBudget) * 3000 : 0;
  const estimatedClicks = Math.floor(estimatedReach * 0.05);
  const estimatedCpc = formData.dailyBudget ? (parseInt(formData.dailyBudget) / estimatedClicks || 0).toFixed(2) : "0.00";

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2" data-testid="text-page-title">Ad Campaign Manager</h1>
          <p className="text-muted-foreground">Create and manage your advertising campaigns</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Create Campaign Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Create New Campaign</CardTitle>
              </CardHeader>
              <CardContent>
                <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); createCampaignMutation.mutate(); }}>
                  {/* Campaign Name */}
                  <div>
                    <Label htmlFor="name">Campaign Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Enter campaign name"
                      required
                      data-testid="input-campaign-name"
                    />
                  </div>

                  {/* Campaign Objective */}
                  <div>
                    <Label htmlFor="objective">Campaign Objective</Label>
                    <Select
                      value={formData.objective}
                      onValueChange={(value) => setFormData({ ...formData, objective: value })}
                    >
                      <SelectTrigger id="objective" data-testid="select-objective">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Brand Awareness">Brand Awareness</SelectItem>
                        <SelectItem value="Website Traffic">Website Traffic</SelectItem>
                        <SelectItem value="Engagement">Engagement</SelectItem>
                        <SelectItem value="App Installs">App Installs</SelectItem>
                        <SelectItem value="Lead Generation">Lead Generation</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Ad Creative */}
                  <div>
                    <Label>Ad Creative</Label>
                    <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer">
                      <input
                        type="file"
                        id="creative"
                        className="hidden"
                        accept="image/*"
                        onChange={(e) => setCreative(e.target.files?.[0] || null)}
                        data-testid="input-creative"
                      />
                      <label htmlFor="creative" className="cursor-pointer">
                        <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-3" />
                        <p className="text-muted-foreground">
                          {creative ? creative.name : "Click to upload image or video"}
                        </p>
                        <p className="text-xs text-muted-foreground mt-2">Max size: 5MB • Formats: JPG, PNG, WEBP</p>
                      </label>
                    </div>
                  </div>

                  {/* Ad Copy */}
                  <div>
                    <Label htmlFor="adCopy">Ad Copy</Label>
                    <Textarea
                      id="adCopy"
                      value={formData.adCopy}
                      onChange={(e) => setFormData({ ...formData, adCopy: e.target.value })}
                      placeholder="Write your ad text here..."
                      rows={3}
                      maxLength={280}
                      required
                      data-testid="textarea-ad-copy"
                    />
                    <p className="text-xs text-muted-foreground mt-1">{formData.adCopy.length}/280 characters</p>
                  </div>

                  {/* Target Audience */}
                  <div>
                    <Label>Target Audience</Label>
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label htmlFor="ageRange" className="text-xs text-muted-foreground">Age Range</Label>
                          <Select
                            value={formData.targetAgeRange}
                            onValueChange={(value) => setFormData({ ...formData, targetAgeRange: value })}
                          >
                            <SelectTrigger id="ageRange" data-testid="select-age-range">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="18-24">18-24</SelectItem>
                              <SelectItem value="25-34">25-34</SelectItem>
                              <SelectItem value="35-44">35-44</SelectItem>
                              <SelectItem value="45-54">45-54</SelectItem>
                              <SelectItem value="55+">55+</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="gender" className="text-xs text-muted-foreground">Gender</Label>
                          <Select
                            value={formData.targetGender}
                            onValueChange={(value) => setFormData({ ...formData, targetGender: value })}
                          >
                            <SelectTrigger id="gender" data-testid="select-gender">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="All">All</SelectItem>
                              <SelectItem value="Male">Male</SelectItem>
                              <SelectItem value="Female">Female</SelectItem>
                              <SelectItem value="Other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="interests" className="text-xs text-muted-foreground">Interests</Label>
                        <Input
                          id="interests"
                          value={formData.targetInterests}
                          onChange={(e) => setFormData({ ...formData, targetInterests: e.target.value })}
                          placeholder="e.g., Technology, Fashion, Sports"
                          data-testid="input-interests"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Budget & Schedule */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="dailyBudget">Daily Budget</Label>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                        <Input
                          id="dailyBudget"
                          type="number"
                          value={formData.dailyBudget}
                          onChange={(e) => setFormData({ ...formData, dailyBudget: e.target.value })}
                          className="pl-8"
                          placeholder="100"
                          required
                          data-testid="input-daily-budget"
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="durationDays">Duration (days)</Label>
                      <Input
                        id="durationDays"
                        type="number"
                        value={formData.durationDays}
                        onChange={(e) => setFormData({ ...formData, durationDays: e.target.value })}
                        placeholder="7"
                        required
                        data-testid="input-duration"
                      />
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-3 pt-4">
                    <Button
                      type="submit"
                      className="flex-1"
                      disabled={createCampaignMutation.isPending}
                      data-testid="button-create-campaign"
                    >
                      {createCampaignMutation.isPending ? "Creating..." : "Create Campaign"}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      className="px-6"
                      data-testid="button-save-draft"
                    >
                      Save Draft
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Campaign Stats Sidebar */}
          <div className="space-y-6">
            {/* Estimated Reach */}
            <Card>
              <CardHeader>
                <CardTitle>Estimated Reach</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-4">
                  <p className="text-4xl font-bold text-primary mb-2" data-testid="text-estimated-reach">
                    {estimatedReach.toLocaleString()}
                  </p>
                  <p className="text-muted-foreground text-sm">Potential impressions</p>
                </div>
                <div className="space-y-2 mt-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Est. clicks</span>
                    <span className="font-semibold" data-testid="text-estimated-clicks">{estimatedClicks.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">CTR</span>
                    <span className="font-semibold">5.0%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">CPC</span>
                    <span className="font-semibold" data-testid="text-estimated-cpc">${estimatedCpc}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Active Campaigns */}
            <Card>
              <CardHeader>
                <CardTitle>Active Campaigns</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-3">
                    <div className="h-16 bg-muted rounded-lg animate-pulse" />
                    <div className="h-16 bg-muted rounded-lg animate-pulse" />
                  </div>
                ) : activeCampaigns.length === 0 ? (
                  <p className="text-muted-foreground text-sm text-center py-4" data-testid="text-no-campaigns">
                    No active campaigns
                  </p>
                ) : (
                  <div className="space-y-3">
                    {activeCampaigns.map((campaign) => (
                      <div key={campaign.id} className="p-3 bg-muted rounded-lg" data-testid={`campaign-${campaign.id}`}>
                        <p className="font-semibold text-sm mb-1">{campaign.name}</p>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">{(campaign.impressions || 0).toLocaleString()} impressions</span>
                          <span className="text-green-500 font-semibold">Active</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Payment Method */}
            <Card>
              <CardHeader>
                <CardTitle>Payment Method</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                  <CreditCard className="text-primary text-2xl" />
                  <div className="flex-1">
                    <p className="font-semibold text-sm">•••• 4242</p>
                    <p className="text-xs text-muted-foreground">Expires 12/25</p>
                  </div>
                  <Button size="sm" variant="ghost" className="text-primary" data-testid="button-change-payment">
                    Change
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
