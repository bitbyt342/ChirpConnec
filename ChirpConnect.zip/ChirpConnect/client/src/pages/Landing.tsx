import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Check } from "lucide-react";
import { SiX } from "react-icons/si";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-background" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <div className="flex items-center justify-center mb-8">
              <SiX className="text-primary text-6xl" />
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Happening now
            </h1>
            
            <p className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-2xl mx-auto">
              Join the conversation. Share your thoughts. Connect with millions around the world.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="text-lg px-8 py-6"
                onClick={() => window.location.href = '/api/login'}
                data-testid="button-login"
              >
                Get Started
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="text-lg px-8 py-6"
                onClick={() => window.location.href = '/api/login'}
                data-testid="button-signup"
              >
                Sign In
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Why join our platform?</h2>
          <p className="text-xl text-muted-foreground">Everything you need to stay connected</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Check className="text-primary" />
                Share Your Voice
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                Post text, images, and videos to share what's on your mind with your followers.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Check className="text-primary" />
                Connect & Engage
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                Like, comment, and repost content. Build meaningful connections with others.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Check className="text-primary" />
                Stay Updated
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                Follow trending topics and hashtags. Never miss what's happening in your world.
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Verification Section */}
      <div className="bg-muted/50 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Get Verified</h2>
            <p className="text-xl text-muted-foreground">
              Stand out with the Blue Tick verification badge
            </p>
          </div>

          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="text-2xl text-center">Premium Features</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <Check className="text-primary mt-1 flex-shrink-0" />
                <div>
                  <p className="font-semibold">Blue verification badge</p>
                  <p className="text-sm text-muted-foreground">Stand out with the iconic Blue Tick</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Check className="text-primary mt-1 flex-shrink-0" />
                <div>
                  <p className="font-semibold">Priority support</p>
                  <p className="text-sm text-muted-foreground">Get help when you need it most</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Check className="text-primary mt-1 flex-shrink-0" />
                <div>
                  <p className="font-semibold">Increased visibility</p>
                  <p className="text-sm text-muted-foreground">Your posts get boosted in feeds</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Check className="text-primary mt-1 flex-shrink-0" />
                <div>
                  <p className="font-semibold">Edit posts</p>
                  <p className="text-sm text-muted-foreground">Fix typos after posting</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Check className="text-primary mt-1 flex-shrink-0" />
                <div>
                  <p className="font-semibold">Longer posts</p>
                  <p className="text-sm text-muted-foreground">Write up to 4,000 characters</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap gap-4 justify-center text-sm text-muted-foreground">
            <a href="#" className="hover:text-foreground">Terms of Service</a>
            <a href="#" className="hover:text-foreground">Privacy Policy</a>
            <a href="#" className="hover:text-foreground">Cookie Policy</a>
            <a href="#" className="hover:text-foreground">Accessibility</a>
            <a href="#" className="hover:text-foreground">Ads info</a>
          </div>
          <p className="text-center text-sm text-muted-foreground mt-4">
            © 2024 Social Corp. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
