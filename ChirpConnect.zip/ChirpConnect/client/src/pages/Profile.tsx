import { useEffect, useState } from "react";
import { useRoute } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/Sidebar";
import RightSidebar from "@/components/RightSidebar";
import PostCard from "@/components/PostCard";
import MobileNav from "@/components/MobileNav";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, MapPin, Link as LinkIcon, BadgeCheck } from "lucide-react";
import type { User, PostWithUser } from "@shared/schema";

export default function Profile() {
  const { toast } = useToast();
  const [, params] = useRoute("/profile/:id");
  const profileId = params?.id;
  const { user: currentUser, isAuthenticated, isLoading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<"posts" | "replies" | "media">("posts");

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: profileUser, isLoading: userLoading } = useQuery<User>({
    queryKey: ["/api/users", profileId],
    enabled: !!profileId,
  });

  const { data: posts, isLoading: postsLoading } = useQuery<PostWithUser[]>({
    queryKey: ["/api/users", profileId, "posts"],
    enabled: !!profileId,
  });

  const { data: followStatus } = useQuery<{ following: boolean }>({
    queryKey: ["/api/users", profileId, "is-following"],
    enabled: !!profileId && currentUser?.id !== profileId,
  });

  const followMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/users/${profileId}/follow`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", profileId, "is-following"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users", profileId] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update follow status",
        variant: "destructive",
      });
    },
  });

  if (authLoading || userLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!profileUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground" data-testid="text-user-not-found">User not found</p>
      </div>
    );
  }

  const isOwnProfile = currentUser?.id === profileId;
  const isFollowing = followStatus?.following || false;

  return (
    <div className="min-h-screen bg-background">
      <MobileNav />
      
      <div className="max-w-7xl mx-auto flex">
        <Sidebar />

        {/* Main Content */}
        <main className="flex-1 border-r border-border min-h-screen">
          {/* Header */}
          <div className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border px-4 py-3">
            <h1 className="text-xl font-bold" data-testid="text-profile-name">{profileUser.firstName} {profileUser.lastName}</h1>
            <p className="text-sm text-muted-foreground" data-testid="text-posts-count">{posts?.length || 0} posts</p>
          </div>

          {/* Profile Header */}
          <div>
            {/* Cover Image Placeholder */}
            <div className="h-48 bg-muted" />
            
            {/* Profile Info */}
            <div className="px-4 pb-4">
              <div className="flex justify-between items-start -mt-16 mb-4">
                <img
                  src={profileUser.profileImageUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profileUser.id}`}
                  alt={profileUser.firstName || "User"}
                  className="w-32 h-32 rounded-full border-4 border-background"
                  data-testid="img-profile-avatar"
                />
                
                {!isOwnProfile && (
                  <Button
                    onClick={() => followMutation.mutate()}
                    variant={isFollowing ? "outline" : "default"}
                    className="mt-16"
                    disabled={followMutation.isPending}
                    data-testid="button-follow"
                  >
                    {followMutation.isPending ? "Loading..." : isFollowing ? "Following" : "Follow"}
                  </Button>
                )}
              </div>

              <div className="mb-4">
                <div className="flex items-center gap-2">
                  <h2 className="text-2xl font-bold" data-testid="text-full-name">
                    {profileUser.firstName} {profileUser.lastName}
                  </h2>
                  {profileUser.isVerified && (
                    <BadgeCheck className="w-6 h-6 text-primary" data-testid="icon-verified" />
                  )}
                </div>
                <p className="text-muted-foreground" data-testid="text-username">@{profileUser.username}</p>
              </div>

              {profileUser.bio && (
                <p className="mb-4" data-testid="text-bio">{profileUser.bio}</p>
              )}

              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span data-testid="text-joined">Joined {new Date(profileUser.createdAt!).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</span>
                </div>
              </div>

              <div className="flex gap-4 text-sm">
                <div>
                  <span className="font-bold" data-testid="text-following-count">{profileUser.followingCount}</span>{" "}
                  <span className="text-muted-foreground">Following</span>
                </div>
                <div>
                  <span className="font-bold" data-testid="text-followers-count">{profileUser.followersCount}</span>{" "}
                  <span className="text-muted-foreground">Followers</span>
                </div>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex border-b border-border">
            <button
              onClick={() => setActiveTab("posts")}
              className={`flex-1 py-4 font-semibold transition-colors ${
                activeTab === "posts"
                  ? "text-foreground border-b-4 border-primary"
                  : "text-muted-foreground hover:bg-accent"
              }`}
              data-testid="button-tab-posts"
            >
              Posts
            </button>
            <button
              onClick={() => setActiveTab("replies")}
              className={`flex-1 py-4 font-semibold transition-colors ${
                activeTab === "replies"
                  ? "text-foreground border-b-4 border-primary"
                  : "text-muted-foreground hover:bg-accent"
              }`}
              data-testid="button-tab-replies"
            >
              Replies
            </button>
            <button
              onClick={() => setActiveTab("media")}
              className={`flex-1 py-4 font-semibold transition-colors ${
                activeTab === "media"
                  ? "text-foreground border-b-4 border-primary"
                  : "text-muted-foreground hover:bg-accent"
              }`}
              data-testid="button-tab-media"
            >
              Media
            </button>
          </div>

          {/* Posts */}
          <div>
            {postsLoading ? (
              <div className="space-y-4 p-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="space-y-3">
                    <Skeleton className="h-12 w-12 rounded-full" />
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                ))}
              </div>
            ) : !posts || posts.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">
                <p data-testid="text-no-posts">No posts yet</p>
              </div>
            ) : (
              posts.map((post) => <PostCard key={post.id} post={post} />)
            )}
          </div>
        </main>

        <RightSidebar />
      </div>
    </div>
  );
}
