import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useInfiniteQuery } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/Sidebar";
import RightSidebar from "@/components/RightSidebar";
import CreatePost from "@/components/CreatePost";
import PostCard from "@/components/PostCard";
import MobileNav from "@/components/MobileNav";
import { Skeleton } from "@/components/ui/skeleton";
import type { PostWithUser } from "@shared/schema";

export default function Home() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<"forYou" | "following">("forYou");

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  const {
    data: postsPages,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    isLoading: postsLoading,
  } = useInfiniteQuery({
    queryKey: ["/api/posts"],
    queryFn: async ({ pageParam = 0 }) => {
      const res = await fetch(`/api/posts?limit=20&offset=${pageParam}`, {
        credentials: "include",
      });
      if (!res.ok) throw new Error(`${res.status}: ${await res.text()}`);
      return res.json() as Promise<PostWithUser[]>;
    },
    getNextPageParam: (lastPage, pages) => {
      if (lastPage.length < 20) return undefined;
      return pages.length * 20;
    },
    initialPageParam: 0,
  });

  const posts = postsPages?.pages.flat() || [];

  useEffect(() => {
    const handleScroll = () => {
      if (
        window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 500 &&
        hasNextPage &&
        !isFetchingNextPage
      ) {
        fetchNextPage();
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <MobileNav />
      
      <div className="max-w-7xl mx-auto flex">
        <Sidebar />

        {/* Main Feed */}
        <main className="flex-1 border-r border-border min-h-screen">
          {/* Feed Header */}
          <div className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border">
            <div className="flex items-center justify-between px-4 py-3">
              <h1 className="text-xl font-bold" data-testid="text-page-title">Home</h1>
            </div>
            
            {/* Tabs */}
            <div className="flex border-b border-border">
              <button
                onClick={() => setActiveTab("forYou")}
                className={`flex-1 py-4 font-semibold transition-colors ${
                  activeTab === "forYou"
                    ? "text-foreground border-b-4 border-primary"
                    : "text-muted-foreground hover:bg-accent"
                }`}
                data-testid="button-tab-foryou"
              >
                For you
              </button>
              <button
                onClick={() => setActiveTab("following")}
                className={`flex-1 py-4 font-semibold transition-colors ${
                  activeTab === "following"
                    ? "text-foreground border-b-4 border-primary"
                    : "text-muted-foreground hover:bg-accent"
                }`}
                data-testid="button-tab-following"
              >
                Following
              </button>
            </div>
          </div>

          <CreatePost />

          {/* Posts Feed */}
          <div>
            {postsLoading ? (
              <div className="space-y-4 p-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="space-y-3">
                    <Skeleton className="h-12 w-12 rounded-full" />
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                ))}
              </div>
            ) : posts.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">
                <p data-testid="text-no-posts">No posts yet. Start following people or create your first post!</p>
              </div>
            ) : (
              <>
                {posts.map((post) => (
                  <PostCard key={post.id} post={post} />
                ))}
                
                {isFetchingNextPage && (
                  <div className="p-8 text-center border-b border-border">
                    <div className="inline-flex items-center gap-2 text-muted-foreground">
                      <div className="animate-spin w-5 h-5 border-2 border-primary border-t-transparent rounded-full" />
                      <span data-testid="text-loading-posts">Loading more posts...</span>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </main>

        <RightSidebar />
      </div>
    </div>
  );
}
