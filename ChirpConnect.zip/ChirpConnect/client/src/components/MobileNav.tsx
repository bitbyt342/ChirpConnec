import { useAuth } from "@/hooks/useAuth";
import { SiX } from "react-icons/si";
import { Home, Search, Bell, Mail } from "lucide-react";
import { Link, useLocation } from "wouter";
import ThemeToggle from "./ThemeToggle";

export default function MobileNav() {
  const { user } = useAuth();
  const [location] = useLocation();

  return (
    <>
      {/* Top Mobile Header */}
      <div className="lg:hidden sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="flex items-center justify-between px-4 py-2">
          {/* User Avatar */}
          <Link href={`/profile/${user?.id}`}>
            <a>
              <img
                src={user?.profileImageUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.id}`}
                alt={user?.firstName || "User"}
                className="w-8 h-8 rounded-full"
                data-testid="img-mobile-avatar"
              />
            </a>
          </Link>

          {/* Logo */}
          <div className="flex items-center">
            <SiX className="text-primary text-2xl" />
          </div>

          {/* Theme Toggle */}
          <ThemeToggle />
        </div>
      </div>

      {/* Bottom Mobile Navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-background border-t border-border z-50">
        <div className="flex justify-around py-2">
          <Link href="/">
            <a className={`flex flex-col items-center gap-1 p-2 ${location === "/" ? "text-foreground" : "text-muted-foreground"}`} data-testid="nav-mobile-home">
              <Home className="w-6 h-6" />
            </a>
          </Link>
          <Link href="/explore">
            <a className={`flex flex-col items-center gap-1 p-2 ${location === "/explore" ? "text-foreground" : "text-muted-foreground"}`} data-testid="nav-mobile-explore">
              <Search className="w-6 h-6" />
            </a>
          </Link>
          <Link href="/notifications">
            <a className={`flex flex-col items-center gap-1 p-2 ${location === "/notifications" ? "text-foreground" : "text-muted-foreground"}`} data-testid="nav-mobile-notifications">
              <Bell className="w-6 h-6" />
            </a>
          </Link>
          <Link href="/messages">
            <a className={`flex flex-col items-center gap-1 p-2 ${location === "/messages" ? "text-foreground" : "text-muted-foreground"}`} data-testid="nav-mobile-messages">
              <Mail className="w-6 h-6" />
            </a>
          </Link>
        </div>
      </nav>
    </>
  );
}
