import { useState } from "react";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, BadgeCheck } from "lucide-react";

if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface SubscriptionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  clientSecret: string;
}

function SubscribeForm({ onSuccess }: { onSuccess: () => void }) {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsSubmitting(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.origin,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Payment Successful",
        description: "You are now verified!",
      });
      onSuccess();
    }

    setIsSubmitting(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <Button 
        type="submit" 
        className="w-full" 
        disabled={!stripe || isSubmitting}
        data-testid="button-subscribe-submit"
      >
        {isSubmitting ? "Processing..." : "Subscribe"}
      </Button>
    </form>
  );
}

export default function SubscriptionModal({ open, onOpenChange, clientSecret }: SubscriptionModalProps) {
  const [selectedPlan, setSelectedPlan] = useState<"monthly" | "annual">("annual");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BadgeCheck className="text-primary" />
            Get Verified
          </DialogTitle>
          <DialogDescription>
            Join the verified community and unlock exclusive features
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Pricing Plans */}
          <div className="grid md:grid-cols-2 gap-4">
            <Card 
              className={`cursor-pointer transition-all ${
                selectedPlan === "monthly" ? "border-primary border-2" : "border-border"
              }`}
              onClick={() => setSelectedPlan("monthly")}
              data-testid="card-modal-plan-monthly"
            >
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>Monthly</CardTitle>
                    <CardDescription>Billed monthly</CardDescription>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-bold">$8</p>
                    <p className="text-sm text-muted-foreground">/month</p>
                  </div>
                </div>
              </CardHeader>
            </Card>

            <Card 
              className={`cursor-pointer transition-all relative ${
                selectedPlan === "annual" ? "border-primary border-2" : "border-border"
              }`}
              onClick={() => setSelectedPlan("annual")}
              data-testid="card-modal-plan-annual"
            >
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-full">
                SAVE 20%
              </div>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>Annual</CardTitle>
                    <CardDescription>Billed annually</CardDescription>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-bold">$84</p>
                    <p className="text-sm text-muted-foreground">/year</p>
                  </div>
                </div>
              </CardHeader>
            </Card>
          </div>

          {/* Payment Form */}
          {clientSecret && (
            <Elements stripe={stripePromise} options={{ clientSecret }}>
              <SubscribeForm onSuccess={() => onOpenChange(false)} />
            </Elements>
          )}

          {/* Features */}
          <div className="space-y-3">
            <h4 className="font-bold">What's included:</h4>
            <div className="flex items-start gap-3">
              <Check className="text-primary mt-1 flex-shrink-0" />
              <div>
                <p className="font-semibold">Blue verification badge</p>
                <p className="text-sm text-muted-foreground">Stand out with the iconic Blue Tick</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="text-primary mt-1 flex-shrink-0" />
              <div>
                <p className="font-semibold">Priority support</p>
                <p className="text-sm text-muted-foreground">Get help when you need it most</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="text-primary mt-1 flex-shrink-0" />
              <div>
                <p className="font-semibold">Increased visibility</p>
                <p className="text-sm text-muted-foreground">Your posts get boosted in feeds</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="text-primary mt-1 flex-shrink-0" />
              <div>
                <p className="font-semibold">Edit posts</p>
                <p className="text-sm text-muted-foreground">Fix typos after posting</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="text-primary mt-1 flex-shrink-0" />
              <div>
                <p className="font-semibold">Longer posts</p>
                <p className="text-sm text-muted-foreground">Write up to 4,000 characters</p>
              </div>
            </div>
          </div>

          <p className="text-xs text-muted-foreground text-center">
            By subscribing, you agree to our Terms and Conditions. Subscription auto-renews until canceled.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
