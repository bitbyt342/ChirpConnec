import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Search, BadgeCheck } from "lucide-react";
import { Link } from "wouter";
import type { Hashtag, User } from "@shared/schema";

export default function RightSidebar() {
  const { data: hashtags } = useQuery<Hashtag[]>({
    queryKey: ["/api/hashtags/trending"],
  });

  const suggestions: User[] = []; // Would be populated from an API endpoint

  return (
    <aside className="hidden xl:block w-96 px-6 py-2">
      {/* Search */}
      <div className="sticky top-0 pt-2 pb-4 bg-background">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
          <Input
            type="text"
            placeholder="Search"
            className="w-full bg-muted rounded-full py-3 pl-12 pr-4 border-0 focus-visible:ring-2 focus-visible:ring-primary"
            data-testid="input-search"
          />
        </div>
      </div>

      {/* Blue Tick Subscription Widget */}
      <Card className="mb-4">
        <CardHeader>
          <CardTitle className="text-xl">Get Verified</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-sm mb-3">
            Subscribe to unlock new features and get the Blue Tick verification badge.
          </p>
          <Link href="/subscribe">
            <Button className="w-full" data-testid="button-subscribe">
              Subscribe Now
            </Button>
          </Link>
        </CardContent>
      </Card>

      {/* Trending Widget */}
      <Card className="mb-4">
        <CardHeader>
          <CardTitle className="text-xl">Trends for you</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {hashtags && hashtags.length > 0 ? (
            <>
              {hashtags.slice(0, 5).map((hashtag) => (
                <div
                  key={hashtag.id}
                  className="px-4 py-3 hover:bg-accent cursor-pointer transition-colors"
                  data-testid={`trend-${hashtag.tag}`}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <p className="text-xs text-muted-foreground">Trending</p>
                      <p className="font-bold">#{hashtag.tag}</p>
                      <p className="text-xs text-muted-foreground">{(hashtag.postsCount || 0).toLocaleString()} posts</p>
                    </div>
                  </div>
                </div>
              ))}
              <Button variant="ghost" className="w-full text-primary hover:bg-accent rounded-none">
                Show more
              </Button>
            </>
          ) : (
            <div className="px-4 py-8 text-center text-muted-foreground">
              <p className="text-sm">No trending topics yet</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Who to Follow Widget */}
      {suggestions.length > 0 && (
        <Card className="mb-4">
          <CardHeader>
            <CardTitle className="text-xl">Who to follow</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {suggestions.slice(0, 3).map((suggestedUser) => (
              <div
                key={suggestedUser.id}
                className="px-4 py-3 hover:bg-accent transition-colors"
                data-testid={`suggestion-${suggestedUser.id}`}
              >
                <div className="flex items-center gap-3">
                  <img
                    src={suggestedUser.profileImageUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${suggestedUser.id}`}
                    alt={suggestedUser.firstName || "User"}
                    className="w-12 h-12 rounded-full"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1">
                      <p className="font-bold text-sm truncate">{suggestedUser.firstName} {suggestedUser.lastName}</p>
                      {suggestedUser.isVerified && <BadgeCheck className="w-4 h-4 text-primary flex-shrink-0" />}
                    </div>
                    <p className="text-muted-foreground text-sm truncate">@{suggestedUser.username}</p>
                  </div>
                  <Button size="sm" className="rounded-full" data-testid={`button-follow-${suggestedUser.id}`}>
                    Follow
                  </Button>
                </div>
              </div>
            ))}
            <Button variant="ghost" className="w-full text-primary hover:bg-accent rounded-none">
              Show more
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Footer Links */}
      <div className="px-4 py-3 text-xs text-muted-foreground flex flex-wrap gap-2">
        <a href="#" className="hover:underline">Terms of Service</a>
        <a href="#" className="hover:underline">Privacy Policy</a>
        <a href="#" className="hover:underline">Cookie Policy</a>
        <a href="#" className="hover:underline">Accessibility</a>
        <a href="#" className="hover:underline">Ads info</a>
        <a href="#" className="hover:underline">More</a>
        <span>© 2024 Social Corp.</span>
      </div>
    </aside>
  );
}
