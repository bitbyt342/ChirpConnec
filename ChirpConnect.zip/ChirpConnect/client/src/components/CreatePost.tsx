import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Image, FileImage, BarChart3, Smile, Calendar } from "lucide-react";

export default function CreatePost() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [content, setContent] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const createPostMutation = useMutation({
    mutationFn: async () => {
      const formData = new FormData();
      formData.append("content", content);
      if (image) {
        formData.append("image", image);
      }

      const res = await fetch("/api/posts", {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      if (!res.ok) {
        const error = await res.text();
        throw new Error(`${res.status}: ${error}`);
      }

      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      setContent("");
      setImage(null);
      setImagePreview(null);
      toast({
        title: "Success",
        description: "Post created successfully",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create post",
        variant: "destructive",
      });
    },
  });

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = () => {
    if (!content.trim() && !image) {
      toast({
        title: "Error",
        description: "Post cannot be empty",
        variant: "destructive",
      });
      return;
    }

    if (content.length > 280) {
      toast({
        title: "Error",
        description: "Post is too long (max 280 characters)",
        variant: "destructive",
      });
      return;
    }

    createPostMutation.mutate();
  };

  return (
    <div className="border-b border-border p-4">
      <div className="flex gap-3">
        <img
          src={user?.profileImageUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.id}`}
          alt={user?.firstName || "User"}
          className="w-12 h-12 rounded-full flex-shrink-0"
          data-testid="img-create-post-avatar"
        />
        <div className="flex-1">
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="What's happening?!"
            className="w-full bg-transparent text-lg border-0 focus-visible:ring-0 resize-none min-h-[80px]"
            maxLength={280}
            data-testid="textarea-create-post"
          />

          {imagePreview && (
            <div className="mt-3 relative">
              <img src={imagePreview} alt="Preview" className="rounded-2xl max-h-96 w-auto" />
              <button
                onClick={() => {
                  setImage(null);
                  setImagePreview(null);
                }}
                className="absolute top-2 right-2 bg-black/50 text-white rounded-full p-2 hover:bg-black/70"
                data-testid="button-remove-image"
              >
                ✕
              </button>
            </div>
          )}

          <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
            <div className="flex gap-1">
              <input
                type="file"
                id="post-image"
                className="hidden"
                accept="image/*"
                onChange={handleImageChange}
                data-testid="input-post-image"
              />
              <label htmlFor="post-image">
                <button
                  type="button"
                  className="p-2 rounded-full text-primary hover:bg-primary/10 transition-colors"
                  onClick={() => document.getElementById("post-image")?.click()}
                  data-testid="button-upload-image"
                >
                  <Image className="w-5 h-5" />
                </button>
              </label>
              <button className="p-2 rounded-full text-primary hover:bg-primary/10 transition-colors" data-testid="button-add-gif">
                <FileImage className="w-5 h-5" />
              </button>
              <button className="p-2 rounded-full text-primary hover:bg-primary/10 transition-colors" data-testid="button-add-poll">
                <BarChart3 className="w-5 h-5" />
              </button>
              <button className="p-2 rounded-full text-primary hover:bg-primary/10 transition-colors" data-testid="button-add-emoji">
                <Smile className="w-5 h-5" />
              </button>
              <button className="p-2 rounded-full text-primary hover:bg-primary/10 transition-colors" data-testid="button-schedule">
                <Calendar className="w-5 h-5" />
              </button>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-sm text-muted-foreground" data-testid="text-char-count">
                {content.length}/280
              </span>
              <Button
                onClick={handleSubmit}
                disabled={createPostMutation.isPending || (!content.trim() && !image)}
                data-testid="button-submit-post"
              >
                {createPostMutation.isPending ? "Posting..." : "Post"}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
