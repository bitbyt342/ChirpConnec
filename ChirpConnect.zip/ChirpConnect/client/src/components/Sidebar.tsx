import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { SiX } from "react-icons/si";
import { Home, Search, Bell, Mail, Bookmark, Users, BadgeCheck, User, MoreHorizontal, Feather } from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  const navItems = [
    { icon: Home, label: "Home", path: "/" },
    { icon: Search, label: "Explore", path: "/explore" },
    { icon: Bell, label: "Notifications", path: "/notifications" },
    { icon: Mail, label: "Messages", path: "/messages" },
    { icon: Bookmark, label: "Bookmarks", path: "/bookmarks" },
    { icon: Users, label: "Communities", path: "/communities" },
    { icon: BadgeCheck, label: "Verified", path: "/subscribe" },
    { icon: User, label: "Profile", path: `/profile/${user?.id}` },
    { icon: MoreHorizontal, label: "More", path: "/more" },
  ];

  return (
    <aside className="hidden lg:flex flex-col w-20 xl:w-72 h-screen sticky top-0 border-r border-border px-2 xl:px-4">
      {/* Logo */}
      <div className="flex items-center py-4 px-3">
        <SiX className="text-primary text-3xl" />
        <span className="ml-4 text-xl font-bold hidden xl:block">Social</span>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 mt-2">
        <ul className="space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            
            return (
              <li key={item.path}>
                <Link href={item.path}>
                  <a
                    className={`flex items-center gap-4 px-3 py-3 rounded-full font-medium transition-colors ${
                      isActive
                        ? "text-foreground bg-accent"
                        : "text-muted-foreground hover:bg-accent hover:text-foreground"
                    }`}
                    data-testid={`nav-${item.label.toLowerCase()}`}
                  >
                    <Icon className="w-6 h-6" />
                    <span className="hidden xl:block text-lg">{item.label}</span>
                  </a>
                </Link>
              </li>
            );
          })}
        </ul>

        {/* Post Button */}
        <Button className="mt-4 rounded-full py-3 w-full xl:w-auto xl:px-8" data-testid="button-post">
          <Feather className="xl:hidden w-5 h-5" />
          <span className="hidden xl:inline">Post</span>
        </Button>
      </nav>

      {/* User Profile Section */}
      <div className="mb-4 px-3 py-3 rounded-full hover:bg-accent cursor-pointer flex items-center gap-3 transition-colors">
        <img
          src={user?.profileImageUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.id}`}
          alt={user?.firstName || "User"}
          className="w-10 h-10 rounded-full"
          data-testid="img-user-avatar"
        />
        <div className="hidden xl:block flex-1 min-w-0">
          <div className="flex items-center gap-1">
            <p className="font-bold text-sm truncate" data-testid="text-user-name">
              {user?.firstName} {user?.lastName}
            </p>
            {user?.isVerified && <BadgeCheck className="w-4 h-4 text-primary flex-shrink-0" />}
          </div>
          <p className="text-muted-foreground text-sm truncate" data-testid="text-user-username">
            @{user?.username}
          </p>
        </div>
        <MoreHorizontal className="text-muted-foreground hidden xl:block" />
      </div>
    </aside>
  );
}
