import { useState } from "react";
import { Link } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { MessageCircle, Repeat2, Heart, Share, BadgeCheck } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import type { PostWithUser } from "@shared/schema";

interface PostCardProps {
  post: PostWithUser;
}

export default function PostCard({ post }: PostCardProps) {
  const { toast } = useToast();
  const [isLiked, setIsLiked] = useState(post.isLiked || false);
  const [isReposted, setIsReposted] = useState(post.isReposted || false);
  const [likesCount, setLikesCount] = useState(post.likesCount || 0);
  const [repostsCount, setRepostsCount] = useState(post.repostsCount || 0);

  const likeMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/posts/${post.id}/like`);
    },
    onMutate: () => {
      setIsLiked(!isLiked);
      setLikesCount(isLiked ? likesCount - 1 : likesCount + 1);
    },
    onError: (error: Error) => {
      setIsLiked(isLiked);
      setLikesCount(likesCount);
      
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update like",
        variant: "destructive",
      });
    },
  });

  const repostMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/posts/${post.id}/repost`);
    },
    onMutate: () => {
      setIsReposted(!isReposted);
      setRepostsCount(isReposted ? repostsCount - 1 : repostsCount + 1);
    },
    onError: (error: Error) => {
      setIsReposted(isReposted);
      setRepostsCount(repostsCount);
      
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to repost",
        variant: "destructive",
      });
    },
  });

  const timeAgo = formatDistanceToNow(new Date(post.createdAt!), { addSuffix: true });

  return (
    <article className="border-b border-border p-4 hover:bg-accent/50 transition-colors cursor-pointer" data-testid={`post-${post.id}`}>
      <div className="flex gap-3">
        <Link href={`/profile/${post.user.id}`}>
          <a onClick={(e) => e.stopPropagation()}>
            <img
              src={post.user.profileImageUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${post.user.id}`}
              alt={post.user.firstName || "User"}
              className="w-12 h-12 rounded-full flex-shrink-0"
              data-testid="img-post-avatar"
            />
          </a>
        </Link>

        <div className="flex-1 min-w-0">
          {/* Post Header */}
          <div className="flex items-center gap-1 flex-wrap">
            <Link href={`/profile/${post.user.id}`}>
              <a className="font-bold hover:underline" onClick={(e) => e.stopPropagation()} data-testid="text-post-author">
                {post.user.firstName} {post.user.lastName}
              </a>
            </Link>
            {post.user.isVerified && <BadgeCheck className="w-4 h-4 text-primary flex-shrink-0" />}
            <span className="text-muted-foreground">@{post.user.username}</span>
            <span className="text-muted-foreground">·</span>
            <span className="text-muted-foreground" data-testid="text-post-time">{timeAgo}</span>
          </div>

          {/* Post Content */}
          <p className="mt-1 text-foreground whitespace-pre-wrap break-words" data-testid="text-post-content">
            {post.content}
          </p>

          {/* Post Image */}
          {post.imageUrl && (
            <div className="mt-3 rounded-2xl overflow-hidden border border-border">
              <img
                src={post.imageUrl}
                alt="Post attachment"
                className="w-full h-auto"
                data-testid="img-post-image"
              />
            </div>
          )}

          {/* Post Actions */}
          <div className="flex justify-between mt-3 max-w-md">
            <button
              className="flex items-center gap-2 text-muted-foreground hover:text-primary group transition-colors"
              onClick={(e) => {
                e.stopPropagation();
                // TODO: Open comment modal
              }}
              data-testid="button-comment"
            >
              <div className="p-2 rounded-full group-hover:bg-primary/10 transition-colors">
                <MessageCircle className="w-5 h-5" />
              </div>
              <span className="text-sm">{post.commentsCount}</span>
            </button>

            <button
              className={`flex items-center gap-2 group transition-colors ${
                isReposted ? "text-green-500" : "text-muted-foreground hover:text-green-500"
              }`}
              onClick={(e) => {
                e.stopPropagation();
                repostMutation.mutate();
              }}
              data-testid="button-repost"
            >
              <div className="p-2 rounded-full group-hover:bg-green-500/10 transition-colors">
                <Repeat2 className="w-5 h-5" />
              </div>
              <span className="text-sm">{repostsCount}</span>
            </button>

            <button
              className={`flex items-center gap-2 group transition-colors ${
                isLiked ? "text-pink-600" : "text-muted-foreground hover:text-pink-600"
              }`}
              onClick={(e) => {
                e.stopPropagation();
                likeMutation.mutate();
              }}
              data-testid="button-like"
            >
              <div className="p-2 rounded-full group-hover:bg-pink-600/10 transition-colors">
                <Heart className={`w-5 h-5 ${isLiked ? "fill-current" : ""}`} />
              </div>
              <span className="text-sm">{likesCount}</span>
            </button>

            <button
              className="flex items-center gap-2 text-muted-foreground hover:text-primary group transition-colors"
              onClick={(e) => {
                e.stopPropagation();
                // TODO: Implement share functionality
              }}
              data-testid="button-share"
            >
              <div className="p-2 rounded-full group-hover:bg-primary/10 transition-colors">
                <Share className="w-5 h-5" />
              </div>
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}
